$(document).ready(function() {
    $('.header__burger').click(function(event) {
    //   $('.header__burger,.header__nav').toggleClass('active');
      $('.header__burger,.header__top-list').toggleClass('active');
    });
}); 